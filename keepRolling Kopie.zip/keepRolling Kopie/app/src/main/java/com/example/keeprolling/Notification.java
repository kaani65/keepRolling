package com.example.keeprolling;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class Notification extends Application {
    public static final String CHANNEL_1_ID = "reminder1";
    public static final String CHANNEL_2_ID = "reminder2";


    @Override
    public void onCreate() {
        super.onCreate();

        createNotificationsChannels();
    }

    private void createNotificationsChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel reminder1 = new NotificationChannel(
                    CHANNEL_1_ID,
                    "Reifenwechsel Reminder",
                    NotificationManager.IMPORTANCE_HIGH
            );
            reminder1.setDescription("This is Channel1");

            NotificationChannel reminder2 = new NotificationChannel(
                    CHANNEL_2_ID,
                    "Reifenwechsel Reminder",
                    NotificationManager.IMPORTANCE_LOW
            );
            reminder1.setDescription("This is Channel2");

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(reminder1);
            manager.createNotificationChannel(reminder2);

        }
    }
}
